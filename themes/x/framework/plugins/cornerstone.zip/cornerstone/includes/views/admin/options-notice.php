<?php
/**
 * View for the admin notice when settings are updated.
 */
?>
<div class="updated">
  <p><?php _e( '<strong>Huzzah!</strong> All settings have been successfully saved.', '__x__' ); ?></p>
</div>