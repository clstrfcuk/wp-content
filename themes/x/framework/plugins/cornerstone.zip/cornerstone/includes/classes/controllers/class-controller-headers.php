<?php

class Cornerstone_Controller_Headers extends Cornerstone_Plugin_Component {

}
